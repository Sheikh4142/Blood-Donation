package com.example.blood_donation_donor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
